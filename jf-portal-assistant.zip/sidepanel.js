// Side panel UI for the J. Fortitude Grant Portal Assistant.
// Reads saved drafts + submission workspaces from the Grant Engine and inserts
// them into the active portal page only when the user clicks Insert.
// File uploads always require manual user action — never programmatic uploads.

const DEFAULTS = { baseUrl: "https://grant-buddy-open.lovable.app", token: "" };
const FN_BASE = (b) => `${b.replace(/\/$/, "")}/functions/v1/portal-assistant`;

const $ = (id) => document.getElementById(id);
const status = (m, err = false) => { const el = $("status"); el.textContent = m || ""; el.className = "status" + (err ? " err" : ""); };

let SELECTED_FIELD = null; // { key, label, multiline, isFileInput }
let SAVED_TEXT_BY_DRAFT = new Map();
let CURRENT_OPP = "";
let CURRENT_WORKSPACE = "";
let WORKSPACE_ASSETS = [];

async function loadAuth() {
  const v = await chrome.storage.local.get(DEFAULTS);
  $("baseUrl").value = v.baseUrl || DEFAULTS.baseUrl;
  $("token").value = v.token || "";
  CURRENT_OPP = (await chrome.storage.local.get({ oppName: "" })).oppName;
  $("oppName").value = CURRENT_OPP;
  CURRENT_WORKSPACE = (await chrome.storage.local.get({ workspaceId: "" })).workspaceId;
}
$("saveAuth").addEventListener("click", async () => {
  await chrome.storage.local.set({ baseUrl: $("baseUrl").value.trim(), token: $("token").value.trim() });
  status("Saved.");
  fetchFeed();
});
$("oppName").addEventListener("input", async (e) => {
  CURRENT_OPP = e.target.value;
  await chrome.storage.local.set({ oppName: CURRENT_OPP });
});

async function api(path, opts = {}) {
  const { baseUrl, token } = await chrome.storage.local.get(DEFAULTS);
  if (!token) throw new Error("Set your access token first.");
  const r = await fetch(`${FN_BASE(baseUrl)}${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(opts.headers || {}),
    },
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

function draftText(d) {
  const parts = [];
  if (d.subject) parts.push(`Subject: ${d.subject}`);
  if (d.email_body) parts.push(d.email_body);
  if (Array.isArray(d.talking_points) && d.talking_points.length) parts.push("Talking points:\n- " + d.talking_points.join("\n- "));
  if (Array.isArray(d.impact_bullets) && d.impact_bullets.length) parts.push("Impact:\n- " + d.impact_bullets.join("\n- "));
  if (d.follow_up_text) parts.push(d.follow_up_text);
  return parts.join("\n\n");
}

function escapeHTML(s) { return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c])); }

function renderDrafts(drafts) {
  SAVED_TEXT_BY_DRAFT.clear();
  $("drafts").innerHTML = drafts.length ? "" : `<p class="muted">No saved pitch drafts.</p>`;
  drafts.forEach((d) => {
    const text = draftText(d);
    SAVED_TEXT_BY_DRAFT.set(d.id, text);
    const el = document.createElement("div");
    el.className = "card";
    el.innerHTML = `
      <div class="title">${escapeHTML(d.target_name || "Untitled")}</div>
      <div class="meta"><span class="tag">${escapeHTML(d.pitch_type || "")}</span><span class="tag">${escapeHTML(d.status || "")}</span></div>
      <pre>${escapeHTML(text || "(empty)")}</pre>
      <div class="row">
        <button data-act="copy">Copy</button>
        <button data-act="insert" class="secondary">Insert into selected field</button>
      </div>`;
    el.querySelector('[data-act="copy"]').onclick = () => doCopy(d.id, text, "draft");
    el.querySelector('[data-act="insert"]').onclick = () => doInsert(d.id, text, "draft");
    $("drafts").appendChild(el);
  });
}

function renderMatches(items) {
  $("matches").innerHTML = items.length ? "" : `<p class="muted">No grant matches yet.</p>`;
  items.forEach((m) => {
    const text = `${m.opportunity_title || ""} — ${m.funder_name || ""}\nFit score: ${m.fit_score}\nRecommended pitch: ${m.recommended_pitch_type || "n/a"}\n\n${m.reasoning || ""}`;
    const el = document.createElement("div");
    el.className = "card";
    el.innerHTML = `
      <div class="title">${escapeHTML(m.opportunity_title || "Untitled")}</div>
      <div class="meta">${escapeHTML(m.funder_name || "")} · fit ${m.fit_score}</div>
      <pre>${escapeHTML(m.reasoning || "")}</pre>
      <div class="row">
        <button data-act="copy">Copy summary</button>
        <button data-act="insert" class="secondary">Insert into selected field</button>
      </div>`;
    el.querySelector('[data-act="copy"]').onclick = () => doCopy(null, text, "match");
    el.querySelector('[data-act="insert"]').onclick = () => doInsert(null, text, "match");
    $("matches").appendChild(el);
  });
}

function renderReports(items) {
  $("reports").innerHTML = items.length ? "" : `<p class="muted">No impact reports.</p>`;
  items.forEach((r) => {
    const text = [r.summary_text, r.grant_language, r.sponsor_language].filter(Boolean).join("\n\n");
    const el = document.createElement("div");
    el.className = "card";
    el.innerHTML = `
      <div class="title">${escapeHTML(r.episode_title || "Episode report")}</div>
      <div class="meta">${r.total_responses} responses · ${(r.top_impact_areas || []).slice(0,3).map(escapeHTML).join(", ")}</div>
      <pre>${escapeHTML(text || "(empty)")}</pre>
      <div class="row">
        <button data-act="copy">Copy</button>
        <button data-act="insert" class="secondary">Insert into selected field</button>
      </div>`;
    el.querySelector('[data-act="copy"]').onclick = () => doCopy(null, text, "report");
    el.querySelector('[data-act="insert"]').onclick = () => doInsert(null, text, "report");
    $("reports").appendChild(el);
  });
}

function renderFields(fields) {
  SELECTED_FIELD = null;
  $("fields").innerHTML = fields.length ? "" : `<p class="muted">Click "Detect portal fields" while focused on the portal tab.</p>`;
  fields.forEach((f) => {
    const el = document.createElement("div");
    el.className = "field";
    el.innerHTML = `
      <div class="lbl">${escapeHTML(f.label)} <span class="tag">${f.multiline ? "multiline" : f.tag}</span></div>
      <div class="row"><button data-act="select" class="secondary">Select</button></div>`;
    el.querySelector('[data-act="select"]').onclick = () => {
      SELECTED_FIELD = f;
      document.querySelectorAll("#fields .field").forEach((n) => (n.style.borderStyle = "dashed"));
      el.style.borderStyle = "solid";
      status(`Selected field: ${f.label}`);
    };
    $("fields").appendChild(el);
  });
}

function renderWorkspaces(workspaces) {
  const sel = $("workspaceSelect");
  const current = CURRENT_WORKSPACE || "";
  sel.innerHTML = `<option value="">— None —</option>` + workspaces.map((w) => {
    const opp = w.opportunities || {};
    const label = `${escapeHTML(opp.title || "Untitled")} — ${escapeHTML(opp.funder_name || "")}`;
    return `<option value="${w.id}" ${w.id === current ? "selected" : ""}>${label}</option>`;
  }).join("");
}

function renderRequirements(items) {
  $("requirements").innerHTML = items.length ? "" : `<p class="muted">No requirements yet.</p>`;
  items.forEach((r) => {
    const el = document.createElement("div");
    el.className = "card";
    el.innerHTML = `
      <div class="title">${escapeHTML(r.title)}</div>
      <div class="meta"><span class="tag">${escapeHTML(r.requirement_type)}</span><span class="tag">${escapeHTML(r.status)}</span></div>`;
    $("requirements").appendChild(el);
  });
}

function renderWorkspaceAssets(items) {
  WORKSPACE_ASSETS = items;
  $("workspaceAssets").innerHTML = items.length ? "" : `<p class="muted">No assets staged.</p>`;
  items.forEach((a) => {
    const text = a.body_text || "";
    const el = document.createElement("div");
    el.className = "card";
    const fileBtn = a.file_url ? `<button data-act="open" class="secondary">Open file</button>` : "";
    el.innerHTML = `
      <div class="title">${escapeHTML(a.title)}</div>
      <div class="meta"><span class="tag">${escapeHTML(a.asset_kind)}</span><span class="tag">${escapeHTML(a.status)}</span></div>
      ${text ? `<pre>${escapeHTML(text.slice(0, 600))}${text.length > 600 ? "…" : ""}</pre>` : ""}
      <div class="row">
        ${text ? `<button data-act="copy">Copy</button>` : ""}
        ${text ? `<button data-act="insert" class="secondary">Insert into selected field</button>` : ""}
        ${fileBtn}
      </div>`;
    if (text) {
      el.querySelector('[data-act="copy"]').onclick = () => doCopy(null, text, "asset", a.id);
      el.querySelector('[data-act="insert"]').onclick = () => doInsert(null, text, "asset", a.id);
    }
    if (a.file_url) {
      el.querySelector('[data-act="open"]').onclick = () => {
        window.open(a.file_url, "_blank", "noopener");
        logAction("upload_prepared", null, SELECTED_FIELD?.label);
      };
    }
    $("workspaceAssets").appendChild(el);
  });
}

async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

async function fetchFeed() {
  status("Loading saved content…");
  try {
    const qs = CURRENT_WORKSPACE ? `?workspace_id=${encodeURIComponent(CURRENT_WORKSPACE)}` : "";
    const data = await api(`/feed${qs}`);
    renderDrafts(data.pitch_drafts || []);
    renderMatches(data.grant_matches || []);
    renderReports(data.impact_reports || []);
    renderWorkspaces(data.submission_workspaces || []);
    renderRequirements(data.workspace_requirements || []);
    renderWorkspaceAssets(data.workspace_assets || []);
    $("workspaceSection").style.display = CURRENT_WORKSPACE ? "block" : "none";
    status("Loaded.");
  } catch (e) { status(e.message, true); }
}

$("workspaceSelect").addEventListener("change", async (e) => {
  CURRENT_WORKSPACE = e.target.value;
  await chrome.storage.local.set({ workspaceId: CURRENT_WORKSPACE });
  fetchFeed();
});

$("reload").addEventListener("click", fetchFeed);

$("detect").addEventListener("click", async () => {
  const tabId = await activeTabId();
  if (!tabId) return status("No active tab.", true);
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "JF_DETECT" });
    if (!res?.ok) throw new Error("Detection failed");
    renderFields(res.fields || []);
    status(`${res.fields.length} field(s) detected.`);
  } catch (e) {
    status("Could not reach the page. Reload the portal tab and try again.", true);
  }
});

async function logAction(action, draftId, fieldLabel) {
  try {
    const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    await api("/log", {
      method: "POST",
      body: JSON.stringify({
        action,
        draft_id: draftId,
        field_label: fieldLabel || null,
        portal_url: tab?.url || null,
        opportunity_name: CURRENT_OPP || null,
      }),
    });
  } catch (e) { /* logging is best-effort */ }
}

async function saveMapping(assetId, sourceKind, sourceId) {
  try {
    const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (!tab?.url || !SELECTED_FIELD) return;
    const host = new URL(tab.url).hostname;
    await api("/save-mapping", {
      method: "POST",
      body: JSON.stringify({
        portal_hostname: host,
        opportunity_name: CURRENT_OPP || null,
        field_label: SELECTED_FIELD.label,
        source_kind: sourceKind || "draft",
        source_id: sourceId || null,
        source_section: "full",
        workspace_id: CURRENT_WORKSPACE || null,
        asset_id: assetId || null,
      }),
    });
  } catch (e) { /* best-effort */ }
}

async function doCopy(draftId, text, kind, assetId) {
  try {
    await navigator.clipboard.writeText(text || "");
    status("Copied to clipboard.");
    logAction("copied", draftId, SELECTED_FIELD?.label);
  } catch { status("Copy failed.", true); }
}

async function doInsert(draftId, text, kind, assetId) {
  if (!SELECTED_FIELD) return status("Select a detected field first.", true);
  if (SELECTED_FIELD.isFileInput) {
    return status("This is a file upload field. Use Open file and upload manually — extension never auto-uploads.", true);
  }
  const tabId = await activeTabId();
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "JF_INSERT", key: SELECTED_FIELD.key, text: text || "" });
    if (!res?.ok) throw new Error(res?.error || "Insert failed");
    status(`Inserted into "${SELECTED_FIELD.label}". Review before submitting.`);
    logAction("inserted", draftId, SELECTED_FIELD.label);
    if (assetId || draftId) saveMapping(assetId, kind === "asset" ? "draft" : (kind || "draft"), draftId);
  } catch (e) { status(e.message, true); }
}

loadAuth().then(fetchFeed).catch(() => {});
