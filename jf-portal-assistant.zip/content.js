// Content script — detects visible text fields and fills the chosen one
// when instructed by the side panel. Never reads or fills password fields.
// Never submits a form.

const SENSITIVE = /pass(word)?|ssn|social.?security|credit.?card|cvv|routing|account.?number|tax.?id|ein|bank/i;

function visible(el) {
  const r = el.getBoundingClientRect();
  if (r.width < 8 || r.height < 8) return false;
  const cs = getComputedStyle(el);
  return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0";
}

function labelFor(el) {
  if (el.labels && el.labels.length) return el.labels[0].innerText.trim();
  const aria = el.getAttribute("aria-label") || el.getAttribute("placeholder");
  if (aria) return aria.trim();
  const id = el.id;
  if (id) {
    const lbl = document.querySelector(`label[for="${CSS.escape(id)}"]`);
    if (lbl) return lbl.innerText.trim();
  }
  // Walk up
  let p = el.parentElement;
  for (let i = 0; i < 3 && p; i++, p = p.parentElement) {
    const lbl = p.querySelector("label");
    if (lbl && lbl.innerText.trim()) return lbl.innerText.trim();
  }
  return el.name || el.id || "Untitled field";
}

function detectFields() {
  const nodes = Array.from(document.querySelectorAll(
    "textarea, input[type=text], input[type=search], input[type=url], input[type=email], input:not([type]), [contenteditable=true]",
  ));
  const fields = [];
  nodes.forEach((el, idx) => {
    if (!visible(el)) return;
    const type = (el.getAttribute("type") || el.tagName).toLowerCase();
    if (type === "password") return;
    const label = labelFor(el);
    if (SENSITIVE.test(label) || SENSITIVE.test(el.name || "") || SENSITIVE.test(el.id || "")) return;
    const key = `jf-field-${idx}`;
    el.setAttribute("data-jf-field", key);
    fields.push({
      key,
      label: label.slice(0, 120),
      tag: el.tagName.toLowerCase(),
      multiline: el.tagName === "TEXTAREA" || el.getAttribute("contenteditable") === "true",
    });
  });
  return fields;
}

function setValue(el, text) {
  if (el.getAttribute("contenteditable") === "true") {
    el.focus();
    el.innerText = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
    return true;
  }
  // For React-controlled inputs we need the native setter.
  const proto = el.tagName === "TEXTAREA"
    ? window.HTMLTextAreaElement.prototype
    : window.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (setter) setter.call(el, text); else el.value = text;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "JF_DETECT") {
    sendResponse({ ok: true, fields: detectFields(), url: location.href, title: document.title });
    return true;
  }
  if (msg?.type === "JF_INSERT") {
    const el = document.querySelector(`[data-jf-field="${CSS.escape(msg.key)}"]`);
    if (!el) return sendResponse({ ok: false, error: "Field no longer present" });
    try { setValue(el, msg.text || ""); el.scrollIntoView({ block: "center", behavior: "smooth" }); }
    catch (e) { return sendResponse({ ok: false, error: String(e) }); }
    sendResponse({ ok: true });
    return true;
  }
});
